import java.util.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Scanner scanner = new Scanner(System.in);
		String target = scanner.nextLine();
		int tileNo = scanner.nextInt();
		String[] tiles = new String[tileNo];
		for(int i = 0; i < tileNo; i++){
			tiles[i] = scanner.nextLine();
		}
		int[][] Table = new int[tiles.length][target.length()];
		initializeTable(Table);
	    P(target, tiles, Table);
	    if(Table[tiles.length-1][target.length()-1] == 99){
	    	System.out.print(0);
	    }
	    else{
	    	System.out.print(Table[tiles.length-1][target.length()-1]);
	  	    System.out.println(buildList(target, tiles, Table));
	  	    
	    }
	  
		
	}
	
	
	static int P(String t, String[] tiles, int[][] Table){

		boolean inBounds = tiles.length > 0 && t.length() > 0;
	
		if(inBounds && Table[tiles.length-1][t.length()-1] != Integer.MAX_VALUE){
			return Table[tiles.length-1][t.length()-1];
		}
		else{
			if(t.length() <= 0){
				//System.out.println("success");
				return 0;
			}
			else if(tiles.length <= 1){
				Table[tiles.length-1][t.length()-1] = 99;
				return 99;
			}
			else{
				int lengthMinusK = t.length() - tiles[tiles.length-1].length();
				if(lengthMinusK < 0){
					lengthMinusK = 0;
				}
				int lastIndex = tiles.length - 1;
				String[] tiles2 = new String[tiles.length-1];
				copy(tiles, tiles2);
				
				if(t.regionMatches(lengthMinusK, tiles[lastIndex], 0, tiles[lastIndex].length())){
					//System.out.print(lastIndex + " ");
	
					Table[tiles.length-1][t.length()-1] = Math.min(P(t.substring(0, lengthMinusK), tiles2, Table) + 1, P(t, tiles2, Table));

				}
				else{
					Table[tiles.length-1][t.length()-1] = P(t, tiles2, Table);
				}
				return Table[tiles.length-1][t.length()-1];
			}
		}
	}
	
	static String buildList(String t, String[] tiles, int[][] Table){
		if(tiles.length <= 1 || t.length() <= 0){
			return "";
		}
		else{
			String[] tiles2 = new String[tiles.length-1];
			copy(tiles, tiles2);
			int lengthMinusK = t.length() - tiles[tiles.length-1].length();
			
			if(Table[tiles.length-1][t.length()-1] == Table[tiles.length-2][t.length()-1]){
				return buildList(t, tiles2, Table);
			}
			else{
				return buildList(t.substring(0, lengthMinusK), tiles2, Table) + " " + (tiles.length-1);
			}
		}
	}
	
	static void copy(String[] one, String[] two){
		for(int i = 0; i < two.length; i++){
			two[i] = one[i];
		}
	}
	
	static void initializeTable(int[][] Table){
		for(int i = 0; i < Table.length; i++){
			for(int j = 0; j < Table[i].length; j++){
				Table[i][j] = Integer.MAX_VALUE;
			}
		}
	}

}
